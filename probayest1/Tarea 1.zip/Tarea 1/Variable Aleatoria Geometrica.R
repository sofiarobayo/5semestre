VariableAleatoriaGeometrica <- function(p){
  sum <- 0
  k <- 1
  vec = c()
  while(sum < 1){
    Px = (1-p)^(k-1)*p
    vec[k] <- Px
    sum = sum + Px
    k = k + 1
  }
  return(vec)
}

VariableAleatoriaGeometrica(0.01)

