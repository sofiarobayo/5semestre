VariableAleatoriaPoisson <- function(lambda){
  sum <- 0
  k <- 1
  vec = c()
  while(sum < 1){
    Px = (lambda^k)/(factorial(k))
    print(Px)
    sum = sum + Px
    vec[k] <- Px
    k = k + 1
  }
  return(vec)

VariableAleatoriaPoisson(0.9)

