Multiplesof9or6 <- function(RangeBegin = 1, RangeEnd = 1000000) {
  cont <- 0
  for (i in RangeBegin:RangeEnd){
    if(i%%6 == 0 || i%%9 == 0){
      cont <- cont + 1
    }
  }
  print(cont)
}
